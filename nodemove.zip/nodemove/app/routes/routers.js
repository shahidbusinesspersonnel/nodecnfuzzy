var path = require('path');
const uploadCtrl = require(path.join(__dirname, '..', 'controllers', 'serviceCtrl.controller'));
const { check } = require('express-validator');

module.exports = (app, upload) => {
    var default_url_path = '/api/hanon/'
    app.post(default_url_path + 'cnvendormatch',[check('vendor_name').isLength({ min: 1 }).withMessage('Please supply vendorName')],
    uploadCtrl.cnVendorNameMatcher);
}
