var path = require('path');
var check = require(path.join(__dirname, 'checkValidObject'));
const NodeGeocoder = require('node-geocoder');
const  GeoPoint = require('geopoint');
var logger = require('logger').createLogger();
let config = require(path.join(__dirname, '..',  '..' ,'configs', 'appConfig'));


exports.getFormattedAddress = function(sourceAddress,  callback){
    // console.log('pincode, address, country', sourceAddress);
    try {
        let pincode = sourceAddress.zipCode;
        let address = sourceAddress.Address_Ln_1;
        let  country = sourceAddress.Country;
        let fetchLatlongFromAddress_resp = {};
        if(check.isUndefinedOrNullOrEmptyOrNoLen(pincode) || check.isUndefinedOrNullOrEmptyOrNoLen(address) || check.isUndefinedOrNullOrEmptyOrNoLen(country)){
            fetchLatlongFromAddress_resp.status = 'ERROR';
            fetchLatlongFromAddress_resp.message = 'Invalid input';
            callback(fetchLatlongFromAddress_resp);
        }
        else{
            const options = {
                provider: 'google',
                apiKey: config.GOOGLE_API_KEY, // for Mapquest, OpenCage, Google Premier
                formatter: null // 'gpx', 'string', ...
              };
              const geocoder = NodeGeocoder(options);
              geocoder.geocode({
                address: address,
                country: country,
                zipcode: pincode
              }, function( err, result){
                console.log('Err', err);
                if(err){
                    fetchLatlongFromAddress_resp.status = 'ERROR';
                    fetchLatlongFromAddress_resp.message = 'Not able to dtetect Lat long';
                    callback(fetchLatlongFromAddress_resp);
                }
                else{
                    if(!check.isUndefinedOrNullOrEmptyOrNoLen(result)){
                        if(!check.isUndefinedOrNullOrEmptyOrNoLen(result[0])){
                            fetchLatlongFromAddress_resp.status = 'SUCCESS';
                            fetchLatlongFromAddress_resp.formattedAddress = result[0]['formattedAddress'];
                            fetchLatlongFromAddress_resp.googlePlaceId = result[0].extra.googlePlaceId;
                            fetchLatlongFromAddress_resp.confidence = result[0].extra.confidence;
                            fetchLatlongFromAddress_resp.streetNumber = result[0].streetNumber;
                            fetchLatlongFromAddress_resp.streetName = result[0].streetName;
                            fetchLatlongFromAddress_resp.city = result[0].city;
                            fetchLatlongFromAddress_resp.zipcode = result[0].zipcode;
                            fetchLatlongFromAddress_resp.countryCode = result[0].countryCode;
                            callback(fetchLatlongFromAddress_resp);
                        }
                    }
                    else{
                        fetchLatlongFromAddress_resp.status = 'ERROR';
                        fetchLatlongFromAddress_resp.message = 'Sorry!! We are not able to parse your Address, Please provide Proper Address.'
                        callback(fetchLatlongFromAddress_resp);
                    }

                }
              });
        }
    } catch (error) {
        console.log('Error ',error);
        let fetchLatlongFromAddress_resp = {};
        fetchLatlongFromAddress_resp.status = 'ERROR';
        fetchLatlongFromAddress_resp.message = 'Not able to dtetect Lat long due to technical error!!';
        callback(fetchLatlongFromAddress_resp);
    }
}

exports.calCulateDistancebetweenPoints = function(origin, destination, callback){
    try {
        let calCulateDistancebetweenPoints_resp = {};
        console.log('origin, destination', origin, destination);
        if(check.isUndefinedOrNullOrEmptyOrNoLen(origin) || check.isUndefinedOrNullOrEmptyOrNoLen(destination)){
            calCulateDistancebetweenPoints_resp.status = 'ERROR';
            calCulateDistancebetweenPoints_resp.message = 'Invalid input';
            callback(calCulateDistancebetweenPoints_resp);
        }
        else{
            point1 = new GeoPoint(origin.latitude, origin.longitude);
            point2 = new GeoPoint(destination.latitude, destination.longitude);
            callback(point1.distanceTo(point2, true));
        }
    } catch (error) {
        console.log('Distance er', error);
        let calCulateDistancebetweenPoints_resp = {};
        calCulateDistancebetweenPoints_resp.status = 'ERROR';
        calCulateDistancebetweenPoints_resp.message = 'Technical Error in calculating the distance';
        callback(calCulateDistancebetweenPoints_resp);
    }
}