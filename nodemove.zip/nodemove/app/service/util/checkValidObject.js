﻿/* global __dirname */
var check = require('check-types');

var isUndefinedOrNullOrEmptyOrNoLen = function (obj) {
    return check.undefined(obj) || check.null(obj) || check.emptyObject(obj) || check.hasLength(obj, 0);
};

exports.isUndefinedOrNullOrEmptyOrNoLen = isUndefinedOrNullOrEmptyOrNoLen;
