let path = require('path');
var check = require(path.join(__dirname, 'checkValidObject'));
const dateFinder = require('datefinder');
const { promisify } = require('util');
const { call } = require('@google-cloud/vision/build/src/helpers');
const sleep = promisify(setTimeout);


exports.fetchRegistrationNumber = function (input, callback) {
    try {
        console.log(input);
        callback(input.replace(/[^a-zA-Z0-9 ]/g, ""));
    } catch (error) {

    }
}

exports.fetchName = function (input, callback) {
    try {
        console.log('temp_Name=', input);
        let temp_Name_list = input.split('\n');
        if(temp_Name_list[0].includes('This')){
            let name = temp_Name_list.slice(1);
            let sub_list = name.toString().split(" ");
            if(sub_list[0].length == 1){
                callback(name.toString().substring(1).replace(",", " "));
            }
            else{
                callback(name.toString().replace(",", " "));
            }
        }
        else{
            let temp_name = input.split(" ");
            if(temp_name[0].length == 1){
                let finaleName = input.substring(1).replace(/\n/g, " ").replace(/[^A-Z0-9 ]/g, "");
                callback(finaleName);
            }
            else{
                callback(input.replace(/\n/g, " ").replace(/[^A-Z0-9 ]/g, ""));
            }
            
        }
        console.log('22=', temp_Name.charAt(0), temp_Name.split(" ")[0]   );
        if(temp_Name.charAt(0).length == 1 && temp_Name.split(" ")[0].length == 1){
            console.log('37=', temp_Name);
            callback(temp_Name.substring(1).trim());
        }
        else{
            console.log('41', temp_Name.trim() );
            callback(temp_Name.trim());
        }

        
        
    } catch (error) {

    }
}

exports.fetchDateOfFirstRegistation = function (input, callback) {
    try {
        callback(input.replace(/\n/g, " ").replace(/[^0-9 ]/g, ""));
    } catch (error) {

    }
}

exports.fetchAddress = function (input, callback) {
    try {
        callback(input.replace(/\n/g, " ").replace(/[^a-zA-Z0-9/ ]/g, ""));
    } catch (error) {

    }
}
exports.fetchVinNumber = function (input, callback) {
    try {
        callback(input.replace(/\n/g, " ").replace(/[^a-zA-Z0-9 ]/g, ""));
    } catch (error) {

    }
}

exports.findVinNumberFromFreeText = function(input, callback){
    try {
        let list_words = input.split('\n');
        let vinNumber = "";
        let counter = 0;
        let response = {};
        for (i =0; i<list_words.length; i++){
            
            if(list_words[i].trim().length == 17 && list_words[i].trim().startsWith('SA')){
                vinNumber = list_words[i].trim();
                response.status = 'SUCCESS';
                response.data = vinNumber;
                callback(response);
            }
            counter = counter + 1;
        }
        if(counter == list_words.length){
            response.status = 'ERROR';
            callback(response);
        }
    } catch (error) {
        
    }
}



