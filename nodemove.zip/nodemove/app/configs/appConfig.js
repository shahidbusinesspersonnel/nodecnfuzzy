let config = {};

// config.port = 3333;
config.port = 3334;
config.GOOGLE_API_KEY = 'AIzaSyBcnhmiI3SF77-OtiOx9wm9uOecgV0ALBg';
config.PLACE_API_ENDPOINT ='https://maps.googleapis.com/maps/api/place/findplacefromtext/';

module.exports = config;
