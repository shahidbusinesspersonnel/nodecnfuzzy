let path = require('path');
var logger = require('logger').createLogger();
var check = require(path.join(__dirname, '..', 'service', 'util', 'checkValidObject'));
let ocr = require(path.join(__dirname, 'ocr.controller'));
var gpsService = require(path.join(__dirname, '..',  'service', 'util', 'gpsService'));
var requestData = require('request');
let config = require(path.join(__dirname, '..', 'configs', 'appConfig'));
var async = require('async');
const { PythonShell } = require('python-shell');
var logger = require('logger').createLogger();
const { validationResult } = require('express-validator');
var check = require(path.join(__dirname, '..', 'service', 'util', 'checkValidObject'));


exports.cnVendorNameMatcher = function(req, res){
	let cnVendorNameMatcher_resp = {};
	try {
		let env = 'DEV';
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			cnVendorNameMatcher_resp.status = 422;
			cnVendorNameMatcher_resp.data =  errors;
			res.send(cnVendorNameMatcher_resp);
		}
		else{
			let wave_no = req.body["wave_no"];
			let vendor_name = req.body["vendor_name"];
			let vendorMasterData = req.body["vendorMasterData"];
	
			let FUZZY_SCRIPT_NAME = "";
			let FUZZY_SCRIPT_OPTIONS = {};
			if (env == 'DEV') {
				FUZZY_SCRIPT_NAME = "chineseVendorMatch_2.py";
				FUZZY_SCRIPT_OPTIONS.args = [wave_no,vendor_name, vendorMasterData];
				FUZZY_SCRIPT_OPTIONS.mode = 'json';
			}
			else{
				FUZZY_SCRIPT_NAME = "chineseVendorMatch_2.py";
				FUZZY_SCRIPT_OPTIONS.args = [1,vendroName, vendorMasterData];
				FUZZY_SCRIPT_OPTIONS.mode = 'json';
			}
			PythonShell.run(FUZZY_SCRIPT_NAME, FUZZY_SCRIPT_OPTIONS, function (err, matchResults) {
				if(err){
					console.log('Fuzzy Matcher has failed to performt the matching', err);
					cnVendorNameMatcher_resp.status = 'ERROR';
					cnVendorNameMatcher_resp.data = "Fuzzy Matcher has failed to performt the matching";
					res.send(cnVendorNameMatcher_resp);
				}
				else{
					cnVendorNameMatcher_resp.status = 'SUCCESS';
					cnVendorNameMatcher_resp.data = matchResults;
					res.send(cnVendorNameMatcher_resp);
				}
			});
		}
	} catch (error) {
		console.log('Fuzzy Matcher has failed to performt the matching', error);
		cnVendorNameMatcher_resp.status = 'ERROR';
		cnVendorNameMatcher_resp.data = "Fuzzy Matcher has failed to performt the matching";
		res.send(cnVendorNameMatcher_resp);
	}
}

