let path = require('path');
let keyFilename = path.join(__dirname, '..', 'configs', 'jlrOcrengine.json');
// const vision = require('@google-cloud/vision');

var vision = require('@google-cloud/vision');
var check = require(path.join(__dirname, '..', 'service', 'util', 'checkValidObject'));
const request = require('request');
var fs = require('fs');
var logger = require('logger').createLogger();
const { PythonShell } = require('python-shell');
const { call } = require('@google-cloud/vision/build/src/helpers');
const { count } = require('console');
const { promisify } = require('util');
const { verify } = require('crypto');
const sleep = promisify(setTimeout);
var Jimp = require('jimp');
var async = require('async');
var parsingService = require(path.join(__dirname, '..', 'service', 'util', 'parsingService'));
// const { PythonShell } = require("python-shell");
// const {spawn} = require("child_process");

let ocr = {};


ocr.googleVisionJLR = function (imageUrl, callback) {
    try {
        let inputOriginalFile = imageUrl;
        console.log('googleVisionJLR', imageUrl);
        let env = 'DEV';
        let PREPAREFOROCR_PYTHON = '';
        let TEXTEXTRACTION_PYTHON = '';
        let IMAGE_BASE_DIR = '';
        let PREPAREFOROCR_PYTHON_OPTIONS = {};
        let TEXTEXTRACTION_PYTHON_OPTIONS = {};
        // 1st apr-2020   31ts mar 2021
        if (env == 'DEV') {
            PREPAREFOROCR_PYTHON = 'jlr_prepareForOCR.py'
            PREPAREFOROCR_PYTHON_OPTIONS.mode = "json";
            IMAGE_BASE_DIR = 'uploads/';
            PREPAREFOROCR_PYTHON_OPTIONS.args = [inputOriginalFile];
        }
        else {
            PREPAREFOROCR_PYTHON = '/home/ubuntu/tcsWebservices/app/service/jlr_prepareForOCR.py'
            PREPAREFOROCR_PYTHON_OPTIONS.mode = "json";
            IMAGE_BASE_DIR = '/home/ubuntu/tcsWebservices/uploads/';
            PREPAREFOROCR_PYTHON_OPTIONS.args = [inputOriginalFile];
            PREPAREFOROCR_PYTHON_OPTIONS.pythonPath = '/usr/bin/python';
        }

        let ocr_resp = {};
        let ocrReadyImageFileName = 'OCRREADY_' + inputOriginalFile;

        PythonShell.run(PREPAREFOROCR_PYTHON, PREPAREFOROCR_PYTHON_OPTIONS, function (err, OCRImageFile) {
            if (err) {
                console.log('Failed to create OCR Ready Image', err);
            }
            else {
                getOcrTextsJLR(ocrReadyImageFileName, function (ocr_response) {
                    if (ocr_response['status'] == 'SUCCESS') {
                        let final_result = {};
                        async.waterfall([
                            function fetchRegistrationNmber(next) {
                                // console.log('Coords=', ocr_response['data_2'])
                                if (!check.isUndefinedOrNullOrEmptyOrNoLen(ocr_response['data_2'].boundingPoly_fetch_registrationNumber)) {
                                    //crop-->Ocr->Parse
                                    cropArea('REGISTRATION_NUMBER', ocrReadyImageFileName, IMAGE_BASE_DIR, ocr_response['data_2'].boundingPoly_fetch_registrationNumber, function (result) {
                                        if(result){
                                            getOcrTextfromCroppedZone('REGISTRATION_NUMBER_' + ocrReadyImageFileName,  function (result) {
                                                if(result['status'] =='SUCCESS'){
                                                    console.log('Registration Number = ', result )
                                                    parsingService.fetchRegistrationNumber(result['data'], function (result) {
                                                        final_result.registrationNumber = result;
                                                        next(null, final_result);
                                                    });
                                                }
                                                else{
                                                    final_result.registrationNumber = 'FAILED';
                                                    next(null, final_result);
                                                }

                                            });
                                        }
                                        else{
                                            next(null, final_result);
                                        }

                                    });
                                }
                                else {
                                    next(null, final_result);
                                }
                            },
                            function fetchName(final_result, next) {
                                if (!check.isUndefinedOrNullOrEmptyOrNoLen(ocr_response['data_2'].boundingPoly_fetch_name)) {
                                    //crop-->Ocr->Parse
                                    cropArea('NAME', ocrReadyImageFileName,IMAGE_BASE_DIR, ocr_response['data_2'].boundingPoly_fetch_name, function (result) {
                                        if(result){
                                            getOcrTextfromCroppedZone('NAME_' + ocrReadyImageFileName, function (result) {
                                                if(result['status'] == 'SUCCESS'){
                                                    parsingService.fetchName(result['data'], function (result) {
                                                        final_result.name = result;
                                                        next(null, final_result);
                                                    });
                                                }
                                                else{
                                                    final_result.name = 'FAILED';
                                                    next(null, final_result);
                                                }

                                            });
                                        }
                                        else{
                                            next(null, final_result);
                                        }

                                    });
                                }
                                else {
                                    next(null, final_result);
                                }
                            },
                            function fetchDateOfFirstRegistation(final_result, next) {
                                if (!check.isUndefinedOrNullOrEmptyOrNoLen(ocr_response['data_2'].boundingPoly_fetch_date_of_first_registration)) {
                                    cropArea('DATEOFFIRSTREGISTRATION', ocrReadyImageFileName, IMAGE_BASE_DIR, ocr_response['data_2'].boundingPoly_fetch_date_of_first_registration, function (result) {
                                        if(result){
                                            getOcrTextfromCroppedZone('DATEOFFIRSTREGISTRATION_' + ocrReadyImageFileName, function (result) {
                                                if(result['status'] =='SUCCESS'){
                                                    parsingService.fetchDateOfFirstRegistation(result['data'], function (result) {
                                                        final_result.dateOfFirstRegistration = result;
                                                        next(null, final_result);
                                                    });
                                                }
                                                else{
                                                    final_result.dateOfFirstRegistration = 'FAILED';
                                                    next(null, final_result);
                                                }

                                            });
                                        }
                                        else{
                                            next(null, final_result);
                                        }

                                    });
                                }
                                else{
                                    next(null, final_result);
                                }
                            },
                            function fetchAddress(final_result, next) {
                                if (!check.isUndefinedOrNullOrEmptyOrNoLen(ocr_response['data_2'].boundingPoly_1_fetch_address && !check.isUndefinedOrNullOrEmptyOrNoLen(ocr_response['data_2'].boundingPoly_2_fetch_address ))) {
                                    //crop-->Ocr->Parse
                                    // console.log('final_result 140',final_result);
                                    cropArea('ADDRESS', ocrReadyImageFileName, IMAGE_BASE_DIR, ocr_response['data_2'], function (result) {
                                        if(result){
                                            getOcrTextfromCroppedZone('ADDRESS_' + ocrReadyImageFileName, function (result) {
                                                if(result['status'] == 'SUCCESS'){
                                                    parsingService.fetchAddress(result['data'], function (result) {
                                                        final_result.address = result;
                                                        next(null, final_result);
                                                    });
                                                }
                                                else{
                                                    final_result.address = 'FAILED';
                                                    next(null, final_result);
                                                }

                                            });
                                        }
                                        else{
                                            next(null, final_result);
                                        }

                                    });
                                }
                                else {
                                    next(null, final_result);
                                }
                            },
                            function fetchVinNumber(final_result, next) {
                                if ( !check.isUndefinedOrNullOrEmptyOrNoLen(ocr_response['data_2'].boundingPoly_fetch_fetch_vinNumber)) {
                                    //crop-->Ocr->Parse
                                    cropArea('VINNUMBER', ocrReadyImageFileName,IMAGE_BASE_DIR, ocr_response['data_2'].boundingPoly_fetch_fetch_vinNumber, function (result) {
                                        getOcrTextfromCroppedZone('VINNUMBER_' + ocrReadyImageFileName, function (result) {
                                            if(result['status'] == 'SUCCESS' && result['data'].trim().length == 17 ){
                                                parsingService.fetchVinNumber(result['data'], function (result) {
                                                    final_result.vinNumber = result;
                                                    next(null, final_result);
                                                });
                                            }
                                            else{
                                                parsingService.findVinNumberFromFreeText(ocr_response['data_1'], function(result){
                                                    if(result['status'] == 'ERROR'){
                                                        final_result.vinNumber = 'FAILED';
                                                    }
                                                    else{
                                                        final_result.vinNumber = result['data'];
                                                        next(null, final_result);
                                                    }
                                                })
                                                
                                            }
                                            
                                        });
                                    });
                                }
                                else {
                                    next(null, final_result);
                                }
                            },
                            function theEnd(next) {
                                console.log('final_result=', final_result);
                                callback(final_result);
                            }
                        ], function (err) {
                            console.log(err);
                        });
                    }
                    else {
                        ocr_resp.status = 'ERROR';
                        ocr_resp.data = 'OCR failed to extract the data';
                        callback(ocr_resp);
                    }
                });
            }
        });
    } catch (error) {
        console.log('383', error);
    }
}


function getOcrTextsJLR(inputFile, callback) {
    try {
        let getOcrTexts_resp = {};

        const client = new vision.ImageAnnotatorClient({
            projectId: 'tcsphotometer',
            keyFilename: keyFilename
        });
        fs.readFile(path.join(__dirname, '..', '..', 'uploads', inputFile), function (err, image_buffer) {
            client
                .textDetection(image_buffer)
                .then(ocr_response_google => {
                    // console.log('193 ocr_response', ocr_response_google[0].fullTextAnnotation.text);
                    if (!check.isUndefinedOrNullOrEmptyOrNoLen(ocr_response_google)) {
                        getOcrTexts_resp.status = 'SUCCESS';
                        getOcrTexts_resp.data_1 = ocr_response_google[0].fullTextAnnotation.text;
                        getCoordinates(ocr_response_google[0].textAnnotations, function (result) {
                            getOcrTexts_resp.data_2 = result;
                            callback(getOcrTexts_resp);
                        });

                        // logger.info('399 Raw response=', ocr_response[0]..textAnnotations);

                    }
                    else {
                        getOcrTexts_resp.status = 'ERROR';
                        callback(getOcrTexts_resp);
                    }
                });
        });
    } catch (error) {
        // console.log('Error in Getting OCR result', error);
        getOcrTexts_resp.status = 'ERROR';
        callback(getOcrTexts_resp);
    }
}



function getCoordinates(input, callback) {
    try {
        let getCoordinates_resp = {};
        let data = {};
        let regSet = false;
        let firstDateOfReg = false;
        for (let i = 1; i < input.length; i++) {
            if ((input[i].description.includes('Registration') || input[i].description.includes('Pegietration') ) && input[i].boundingPoly.vertices[0].y > 145    && regSet == false) {
            // if (input[i].description.includes('Registration')) {
                // console.log('249', input[i].boundingPoly.vertices[0]);
                data.description_fetch_registrationNumber = input[i].description;
                data.boundingPoly_fetch_registrationNumber = input[i].boundingPoly;
                regSet = true;
            }
            if (input[i].description.includes('C.1.1') || input[i].description.includes('1.1')) {
                data.description_fetch_name = input[i].description;
                data.boundingPoly_fetch_name = input[i].boundingPoly;
            }
            if (input[i].description.includes('first') ) {
                data.description_fetch_date_of_first_registration = input[i].description;
                data.boundingPoly_fetch_date_of_first_registration = input[i].boundingPoly;
            }
            if (input[i].description == 'C.1.3' || input[i].description == 'CAPITAL' || input[i].description.includes('1.3') || input[i].description.includes('С.1.3')) {
                if (input[i].description == 'C.1.3' || input[i].description.includes('С.1.3')) {
                    data.description_1_fetch_address = input[i].description;
                    data.boundingPoly_1_fetch_address = input[i].boundingPoly;
                }
                if (input[i].description == 'CAPITAL') {
                    data.description_2_fetch_address = input[i].description;
                    data.boundingPoly_2_fetch_address = input[i].boundingPoly;
                }
            }
            if (input[i].description.includes('VIN/Chassis/Frame') || input[i].description.includes('VIN/Chassis') || input[i].description.includes('VIN/Chassis/')) {
                data.description_fetch_vinNumber = input[i].description;
                data.boundingPoly_fetch_fetch_vinNumber = input[i].boundingPoly;
            }
        }
        sleep(500).then(() => {
            callback(data);
        });
    } catch (error) {
        callback(false);
        console.log('Error', error);
    }
}

function cropArea(VAL_TYPE, ocrReadyImageFileName, IMAGE_BASE_DIR, refCoordsAndData, callback) {
    try {
        if (VAL_TYPE == 'ADDRESS') {
            let source_X = refCoordsAndData.boundingPoly_1_fetch_address.vertices[0].x;
            let source_Y = refCoordsAndData.boundingPoly_1_fetch_address.vertices[0].y;
            let dest_X = refCoordsAndData.boundingPoly_2_fetch_address.vertices[0].x;
            let dest_Y = refCoordsAndData.boundingPoly_2_fetch_address.vertices[0].y;
            console.log('cropping address')
            Jimp.read(IMAGE_BASE_DIR + ocrReadyImageFileName).then(imageBuffer => {
                imageBuffer.crop(source_X + 50, source_Y -15 , dest_X - source_X + 100, dest_Y - source_Y  ).write(IMAGE_BASE_DIR + VAL_TYPE + '_' + ocrReadyImageFileName, function (err, savedFileName) {
                    if(err){
                        callback(false)
                    }
                    else{
                        callback(true);
                    }
                });
            });
        }
        else {
            console.log('refdsAndData', refCoordsAndData);
            let source_X = refCoordsAndData.vertices[0].x;
            let source_Y = refCoordsAndData.vertices[0].y;
            if(VAL_TYPE == 'REGISTRATION_NUMBER'){
                Jimp.read(IMAGE_BASE_DIR + ocrReadyImageFileName).then(imageBuffer => {
                    imageBuffer.crop(source_X + 75, source_Y -3, 150, 35).write(IMAGE_BASE_DIR + VAL_TYPE + '_' + ocrReadyImageFileName, function (err, savedFileName) {
                        if(err){
                            callback('ERROR')
                        }
                        else{
                            callback('SUCCESS');
                        }
                    });
                });
            }
            else if(VAL_TYPE == 'NAME'){
                Jimp.read(IMAGE_BASE_DIR + ocrReadyImageFileName).then(imageBuffer => {
                    imageBuffer.crop(source_X + 35, source_Y -28, 475, 60).write(IMAGE_BASE_DIR + VAL_TYPE + '_' + ocrReadyImageFileName, function (err, savedFileName) {
                        if(err){
                            callback('ERROR')
                        }
                        else{
                            callback('SUCCESS');
                        }
                    });
                });
            }
            else if(VAL_TYPE == 'DATEOFFIRSTREGISTRATION'){
                Jimp.read(IMAGE_BASE_DIR + ocrReadyImageFileName).then(imageBuffer => {
                    imageBuffer.crop(source_X + 150, source_Y -10, 250, 25).write(IMAGE_BASE_DIR + VAL_TYPE + '_' + ocrReadyImageFileName, function (err, savedFileName) {
                        if(err){
                            callback('ERROR')
                        }
                        else{
                            callback('SUCCESS');
                        }
                    });
                });
            }
            else if(VAL_TYPE == 'VINNUMBER'){
                Jimp.read(IMAGE_BASE_DIR + ocrReadyImageFileName).then(imageBuffer => {
                    imageBuffer.crop(source_X + 200, source_Y -10, 225, 30).write(IMAGE_BASE_DIR + VAL_TYPE + '_' + ocrReadyImageFileName, function (err, savedFileName) {
                        if(err){
                            callback('ERROR')
                        }
                        else{
                            callback('SUCCESS');
                        }
                    });
                });
            }

        }

    } catch (error) {

    }
}

function getOcrTextfromCroppedZone(inputFileName, callback) {
    try {
        console.log('inputFileName', inputFileName);
        let getOcrTexts_resp = {};
        const client = new vision.ImageAnnotatorClient({
            projectId: 'tcsphotometer',
            keyFilename: keyFilename
        });
        fs.readFile(path.join(__dirname, '..', '..', 'uploads', inputFileName), function (err, image_buffer) {
            client
                .textDetection(image_buffer)
                .then(ocr_response_google => {
                    // console.log('193 ocr_response', ocr_response_google);
                    if (!check.isUndefinedOrNullOrEmptyOrNoLen(ocr_response_google) && !check.isUndefinedOrNullOrEmptyOrNoLen(ocr_response_google[0].fullTextAnnotation)) {
                        getOcrTexts_resp.status = 'SUCCESS';
                        getOcrTexts_resp.data = ocr_response_google[0].fullTextAnnotation.text;
                        console.log('getOcrTexts_resp', getOcrTexts_resp);
                        callback(getOcrTexts_resp);
                    }
                    else {
                        console.log('452 getOcrTexts_resp', getOcrTexts_resp);
                        getOcrTexts_resp.status = 'ERROR';
                        callback(getOcrTexts_resp);
                    }
                });
        });
    } catch (error) {
        console.log('Error in Getting OCR result', error);
        getOcrTexts_resp.status = 'ERROR';
        callback(getOcrTexts_resp);
    }
}

module.exports = ocr;
