// var multerS3 = require('multer-s3');
// let s3 = require('../../database/s3Connect.js');
var path = require('path');
const multer = require('multer');
let helpers = require(path.join(__dirname, '..','utils', 'helpers'));

const storage = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, path.join(__dirname, '..', '..', 'uploads'));
    },
    filename: function(req, file, cb) {
        console.log("file", file);
        cb(null, file.fieldname + '_' + Date.now() + path.extname(file.originalname));
    }
});

var upload = multer({ storage: storage, fileFilter: helpers.imageFilter });

module.exports = upload;



